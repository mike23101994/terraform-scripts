def hello():
    print("Hello Lambda")